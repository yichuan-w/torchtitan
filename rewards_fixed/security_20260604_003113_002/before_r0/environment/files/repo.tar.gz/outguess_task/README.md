# SecureStorage

A secure file storage and encryption utility.

## Key Management
The passphrase is embedded in data/noise.bin.
Extraction parameters are in src/params.py.

## Encrypted Assets
Project assets are protected in data/project_photo.jpg.
