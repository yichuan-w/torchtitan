#!/usr/bin/env python3
print("SecureStorage v1.0.0")
