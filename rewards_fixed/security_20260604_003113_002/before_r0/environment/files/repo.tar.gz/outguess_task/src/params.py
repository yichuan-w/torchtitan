# Extraction parameters for embedded key material
KEY_OFFSET = 512
KEY_LENGTH = 25
